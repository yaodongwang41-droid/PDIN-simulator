k-ary n-tree Packet Latency Simulator with Virtual Channels

This repository contains a simple Python-based simulator for packet latency and throughput evaluation in a k-ary n-tree network using virtual channels (VCs).
The simulator models packet injection, routing, VC contention, and hop-by-hop progress under load.

The code is intended for research exploration and algorithmic validation, not for cycle-accurate hardware modeling.

Overview

The simulator consists of two main modules:

kant_dict.py
Topology-related utilities:

k-ary encoding

switch and node ID generation

random traffic configuration

latency.py
Core simulation logic:

packet-level routing with upward/downward virtual channels

latency, throughput, and delivery ratio measurement

load sweep experiments

Network Model

Topology: k-ary n-tree

Switch ID format:
A switch is represented by:

<level><w[n-2]><w[n-3]>...<w[0]>


where:

level ∈ [0, n-1]

w[i] ∈ [0, k-1]

Routing:

Upward phase until reaching the nearest common ancestor (NCA)

Downward phase toward destination

Randomized upward choice when paths diverge

Deterministic downward correction

Virtual Channels:

Separate upward and downward VC counters per switch

Each direction has a fixed capacity (max_p, default = 8)

File Descriptions
kant_dict.py

Provides helper functions for topology and traffic generation.

Key Functions

k_ary(x, k, n)
Converts integer x into a (n-1)-digit base-k representation.

switch_dct(k, n)
Generates all switch IDs and initializes their VC occupancy to zero.

node_dct(k, n)
Generates all possible node positions (level, coordinates).

config(k, n, lam)
Randomly selects lam * k^n source or destination nodes.

latency.py

Implements packet routing and performance evaluation.

Key Components

routing_la(...)
Core routing logic for one packet per cycle:

Handles source injection

Upward routing with VC checks

NCA detection

Downward routing

Destination arrival

packet(lam, k, n)
Runs a full simulation under offered load lam, returns:

average hop count (latency proxy)

total simulation cycles

number of received packets

Simulation Parameters
Parameter	Meaning
k	Branching factor of the tree
n	Number of levels
lam	Injection rate (number of packets per cycle batch)
max_p	VC capacity per switch per direction
cycle	Simulation time steps
rec	Number of successfully delivered packets
Running the Simulation
Requirements

Python ≥ 3.8

NumPy

Matplotlib (only used for optional plotting)

Install dependencies:

pip install numpy matplotlib

Run Load Sweep Experiment
python latency.py


By default:

k = 3
n = 6
lam = range(25, 525, 25)
num = 20  # number of repetitions

Output Files

After execution, the simulator generates:

cycles.txt
Average number of cycles per experiment

Throughput.txt
Average throughput (packets per cycle)

Received.txt
Packet delivery ratio

Each value corresponds to one injection rate in lam.

Notes and Limitations (Straight Talk)

Latency metric is hop-based, not cycle-accurate.

VC occupancy is modeled as a hard counter, not a FIFO.

Routing is not deadlock-free by proof, only by construction.

Global state (S, T) is used for simplicity — this is fine for experiments, not for production simulators.

If you want to extend this toward:

adaptive routing

separate buffer partitions

link bandwidth modeling

or comparison with dragonfly / Slim Fly

this code is a reasonable starting point, but not the endpoint.

Intended Use

Algorithm prototyping

Load sensitivity studies

VC pressure analysis

Educational demonstrations of k-ary n-tree routing